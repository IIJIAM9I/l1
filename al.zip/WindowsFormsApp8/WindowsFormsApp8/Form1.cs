﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp8
{
    public partial class Form1 : Form
    {
        public string d;
        public string n1;
        public bool n2;
        public Form1()
        {
            n2 = false;
            InitializeComponent();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            if (n2)
            {
                n2 = false;
                textBox1.Text = "";
            }
            Button button = (Button)sender;
            textBox1.Text = textBox1.Text + button.Text;
        }

        private void button15_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
        }

        private void button14_Click(object sender, EventArgs e)
        {
            Button button = (Button)sender;
            d = button.Text;
            n1 = textBox1.Text;
            n2 = true;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Text = "Калькулятор";
        }

        private void button16_Click(object sender, EventArgs e)
        {
            double an1, bn2, r;
            r = 0;
            an1 = Convert.ToDouble(n1);
            bn2 = Convert.ToDouble(textBox1.Text);
            if (d == "+")
            {
                r = an1 + bn2;
            }
            if (d == "-")
            {
                r = an1 - bn2;
            }
            if (d == "*")
            {
                r = an1 * bn2;
            }
            if (d == "/")
            {
                r = an1 / bn2;
            }
            d = "=";
            n2 = true;
            textBox1.Text = r.ToString();
        }
    }
}